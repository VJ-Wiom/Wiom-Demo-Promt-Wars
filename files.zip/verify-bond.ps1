# ============================================================
# Wiom Demo — Router Deploy + Verify Script
# Run this any time you want to re-verify the router
# Must be connected to Bond WiFi (dhoni_0000) first!
# ============================================================

$SSH_KEY     = "$env:USERPROFILE\.ssh\gx-key1"
$ROUTER_IP   = "172.16.2.1"
$ROUTER_USER = "wiom"
$PASSPHRASE  = "smortsecurity"
$FLASK_URL   = "http://localhost:8080/verify"
$NODE_URL    = "http://localhost:3001"

Write-Host ""
Write-Host "  Wiom — Router Verification" -ForegroundColor Cyan
Write-Host ""

# ── Check WiFi ──────────────────────────────────────────────
$wifiIP = (Get-NetIPAddress -InterfaceAlias "Wi-Fi" -AddressFamily IPv4 -ErrorAction SilentlyContinue).IPAddress
if ($wifiIP -notlike "172.16.2.*") {
    Write-Host "[!] Not on Bond WiFi! Current WiFi IP: $wifiIP" -ForegroundColor Red
    Write-Host "    Connect to dhoni_0000 first, then re-run this script." -ForegroundColor Red
    exit 1
}
Write-Host "[✓] On Bond WiFi — IP: $wifiIP" -ForegroundColor Green

# ── Get signed proof from Flask ─────────────────────────────
Write-Host "[*] Getting signed proof from Flask..." -ForegroundColor Yellow
try {
    $proof = Invoke-RestMethod -Uri $FLASK_URL -Method GET -ErrorAction Stop
    $mac = $proof.mac
    $signature = $proof.signature
    $timestamp = $proof.timestamp
    Write-Host "[✓] Got proof for MAC: $mac" -ForegroundColor Green
} catch {
    Write-Host "[!] Flask not running! Start bond_firmware.py first." -ForegroundColor Red
    exit 1
}

# ── Deploy nc server to router via SSH ──────────────────────
Write-Host "[*] Deploying to router $ROUTER_IP..." -ForegroundColor Yellow

$RESP = ($proof | ConvertTo-Json -Compress)
$script = @"
#!/bin/sh
RESP='$RESP'
while true; do
  printf "HTTP/1.1 200 OK\r\nContent-Type: application/json\r\nConnection: close\r\n\r\n\$RESP" | nc -l -p 5000
done
"@

# Kill any existing nc server and redeploy
$sshCmd = "pkill -f 'nc -l -p 5000' 2>/dev/null; echo '$script' > /tmp/serve.sh; chmod +x /tmp/serve.sh; /tmp/serve.sh &"

# Use plink if available, else ssh
$plinkPath = "C:\Program Files\PuTTY\plink.exe"
if (Test-Path $plinkPath) {
    & $plinkPath -i $SSH_KEY -pw $PASSPHRASE "$ROUTER_USER@$ROUTER_IP" $sshCmd
} else {
    $env:SSH_ASKPASS_REQUIRE = "never"
    echo $PASSPHRASE | ssh -i $SSH_KEY -o StrictHostKeyChecking=no "$ROUTER_USER@$ROUTER_IP" $sshCmd
}

Start-Sleep -Seconds 2
Write-Host "[✓] Router server deployed on port 5000" -ForegroundColor Green

# ── POST proof to Node backend ──────────────────────────────
Write-Host "[*] Posting proof to verification backend..." -ForegroundColor Yellow
try {
    $body = @{ mac = $mac; signature = $signature; timestamp = $timestamp } | ConvertTo-Json
    $result = Invoke-RestMethod -Uri "$NODE_URL/upload" -Method POST -ContentType "application/json" -Body $body -ErrorAction Stop
    if ($result.success) {
        Write-Host "[✓] VERIFIED: $($result.device.partner_name) — $($result.device.mac_address)" -ForegroundColor Green
    } else {
        Write-Host "[!] Verification failed: $($result.reason)" -ForegroundColor Red
    }
} catch {
    Write-Host "[!] Node backend error: $_" -ForegroundColor Red
}

Write-Host ""
Write-Host "  Done! Check the dashboard for live status." -ForegroundColor Cyan
Write-Host ""
