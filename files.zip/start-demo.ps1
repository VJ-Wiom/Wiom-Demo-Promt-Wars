# ============================================================
# Wiom Demo — Full Startup Script
# Run this ONCE from internet WiFi to start everything
# ============================================================

$DEMO_DIR = "C:\Users\abc\Desktop\wiom-demo"
$SSH_KEY   = "$env:USERPROFILE\.ssh\gx-key1"
$ROUTER_IP = "172.16.2.1"
$ROUTER_USER = "wiom"
$BOND_WIFI = "dhoni_0000"

Write-Host ""
Write-Host "=====================================================" -ForegroundColor Cyan
Write-Host "  WIOM ROUTER VERIFICATION DEMO — STARTUP" -ForegroundColor Cyan
Write-Host "=====================================================" -ForegroundColor Cyan
Write-Host ""

# ── STEP 1: Kill any old Node/Python processes ────────────────
Write-Host "[1/6] Cleaning up old processes..." -ForegroundColor Yellow
Stop-Process -Name node -Force -ErrorAction SilentlyContinue
Stop-Process -Name python -Force -ErrorAction SilentlyContinue
Start-Sleep -Seconds 1
Write-Host "      Done." -ForegroundColor Green

# ── STEP 2: Start Flask (bond_firmware.py) ───────────────────
Write-Host "[2/6] Starting Flask signature server..." -ForegroundColor Yellow
Start-Process powershell -ArgumentList "-NoExit", "-Command", "cd '$DEMO_DIR'; python bond_firmware.py" -WindowStyle Normal
Start-Sleep -Seconds 3
Write-Host "      Flask running on http://localhost:8080" -ForegroundColor Green

# ── STEP 3: Start Node backend ───────────────────────────────
Write-Host "[3/6] Starting Node verification backend..." -ForegroundColor Yellow
Start-Process powershell -ArgumentList "-NoExit", "-Command", "cd '$DEMO_DIR'; node server.js" -WindowStyle Normal
Start-Sleep -Seconds 3
Write-Host "      Node running on http://localhost:3001" -ForegroundColor Green

# ── STEP 4: Open Dashboard ───────────────────────────────────
Write-Host "[4/6] Opening live dashboard..." -ForegroundColor Yellow
$dashboardPath = "$DEMO_DIR\dashboard.html"
Start-Process $dashboardPath
Write-Host "      Dashboard opened in browser." -ForegroundColor Green

# ── STEP 5: Connect to Bond WiFi ────────────────────────────
Write-Host "[5/6] Switching to Bond WiFi ($BOND_WIFI)..." -ForegroundColor Yellow
Write-Host "      NOTE: You will LOSE internet when you switch." -ForegroundColor Red
Write-Host "      Press any key when you have manually connected to $BOND_WIFI..." -ForegroundColor Yellow
$null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")

# Verify WiFi IP
$wifiIP = (Get-NetIPAddress -InterfaceAlias "Wi-Fi" -AddressFamily IPv4 -ErrorAction SilentlyContinue).IPAddress
if ($wifiIP -like "172.16.2.*") {
    Write-Host "      Connected! WiFi IP: $wifiIP" -ForegroundColor Green
} else {
    Write-Host "      WARNING: WiFi IP is $wifiIP — not on 172.16.2.x network!" -ForegroundColor Red
    Write-Host "      Make sure you connected to $BOND_WIFI and try again." -ForegroundColor Red
}

# ── STEP 6: Deploy to router + verify ───────────────────────
Write-Host "[6/6] Deploying to router and verifying..." -ForegroundColor Yellow
Write-Host "      Running verify-bond.ps1..." -ForegroundColor Yellow
& "$DEMO_DIR\verify-bond.ps1"

Write-Host ""
Write-Host "=====================================================" -ForegroundColor Cyan
Write-Host "  DEMO IS LIVE! Check the dashboard." -ForegroundColor Green
Write-Host "=====================================================" -ForegroundColor Cyan
Write-Host ""
